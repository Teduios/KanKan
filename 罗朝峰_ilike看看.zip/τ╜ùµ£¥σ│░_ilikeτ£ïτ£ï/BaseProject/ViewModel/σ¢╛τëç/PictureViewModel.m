//
//  PictureViewModel.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureViewModel.h"

@implementation PictureViewModel

- (id)initWithPictureType:(PictureType)type
{
    if (self = [super init]) {
        self.type = type;
    }
    return self;
}

/** 防御性编程，不允许使用init初始化 */
- (id)init{
    if (self = [super init]) {
        //%s->__func__  会显示 哪个类中的哪个方法
        NSAssert1(NO, @"%s 必须使用initWithPictureType初始化", __func__);
    }
    return self;
}

- (NSInteger)rowNumber
{
    return self.dataArr.count;
}

- (Body *)bodyForRow:(NSInteger)row
{
    return self.dataArr[row];
}

- (NSURL *)picURLForRow:(NSInteger)row
{
    NSArray *img = [self bodyForRow:row].img;
    PicBodyImgModel *imgModel = img.firstObject;
    return [NSURL URLWithString:imgModel.url];
}

- (NSInteger)likeForRow:(NSInteger)row
{
    return [self bodyForRow:row].likes;
}

- (NSInteger)commentsForRow:(NSInteger)row
{
    return [self bodyForRow:row].commentsall;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [PictureNetManager getPictureWithType:_type page:_page completionHandle:^(PictureModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.body];
        completionHandle(error);
    }];
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}



@end
