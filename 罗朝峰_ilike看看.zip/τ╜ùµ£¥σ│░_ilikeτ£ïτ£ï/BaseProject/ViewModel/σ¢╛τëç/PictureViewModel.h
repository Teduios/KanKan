//
//  PictureViewModel.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "PictureModel.h"
#import "PictureNetManager.h"
@interface PictureViewModel : BaseViewModel

/** 必须使用下方初始化方法 */
- (id)initWithPictureType:(PictureType)type;
@property(nonatomic)PictureType type;

@property(nonatomic) NSInteger rowNumber;
- (NSURL *)picURLForRow:(NSInteger)row;
- (NSInteger)likeForRow:(NSInteger)row;
- (NSInteger)commentsForRow:(NSInteger)row;

@property(nonatomic) NSInteger page;

@end
