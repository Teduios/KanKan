//
//  VideoViewModel.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoNetManager.h"

@interface VideoViewModel : BaseViewModel

@property(nonatomic) NSInteger rowNumber;
@property(nonatomic) NSInteger index;

/** 标题 */
- (NSString *)titleForRow:(NSInteger)row;
/** 详情 */
- (NSString *)descForRow:(NSInteger)row;
/** 封面 */
- (NSURL *)iconURLForRow:(NSInteger)row;
/** 视频链接 */
- (NSURL *)videoURLForRow:(NSInteger)row;


@end
