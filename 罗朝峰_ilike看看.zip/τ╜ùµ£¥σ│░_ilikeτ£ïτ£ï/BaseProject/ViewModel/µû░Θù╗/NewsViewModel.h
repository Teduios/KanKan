//
//  NewsViewModel.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "NewsModel.h"
#import "NewsNetManager.h"

@interface NewsViewModel : BaseViewModel
/** 必须使用此初始化方法，需要一个类型 */
- (instancetype)initWithNewsType:(NewsType)type;
@property(nonatomic) NewsType type;

/** 行数 */
@property(nonatomic) NSInteger rowNumber;
/** 判断某一行数据是否有多张图 */
- (BOOL)containImages:(NSInteger)row;
/** 判断某一行数据是否是专题或web */
- (BOOL)isTopic2:(NSInteger)row;
/** 判断某一行数据是否是比赛直播 */
- (BOOL)isSportsLive:(NSInteger)row;
/** 判断某一行数据标题是否有图 */
- (BOOL)containIcon:(NSInteger)row;

/** 返回列表中某行数据的图片 */
- (NSURL *)iconURLForRow:(NSInteger)row;
/** 返回列表中某行数据题目 */
- (NSString *)titleForRow:(NSInteger)row;
/** 返回列表中某行的日期 */
- (NSString *)dateForRow:(NSInteger)row;
/** 返回列表中某行数据评论次数 */
- (NSString *)commentsForRow:(NSInteger)row;

/** 通过行数 返回此行中对应的图片链接数组 */
- (NSArray *)iconURLSForRowInList:(NSInteger)row;


/** 返回此行中对应的详情页面 */
- (NSString *)detailURLForRow:(NSInteger)row;


/** 比赛直播 */
- (NSURL *)leftLogoURLForRow:(NSInteger)row;
- (NSString *)leftNameForRow:(NSInteger)row;
//- (NSString *)leftScoreForRow:(NSInteger)row;
- (NSURL *)rightLogoURLForRow:(NSInteger)row;
- (NSString *)rightNameForRow:(NSInteger)row;
//- (NSString *)rightScoreForRow:(NSInteger)row;
- (NSString *)scoreForRow:(NSInteger)row;

/** 存放头部滚动栏 */
@property (nonatomic, strong)NSArray *indexPicArr;
/** 是否有头部滚动栏 */
@property (nonatomic, getter=isExistIndexPic) BOOL existIndexPic;
/** 滚动展示栏的图片 */
- (NSURL *)iconURLForRowInIndexPic:(NSInteger)row;
/** 滚动展示栏的文字 */
- (NSString *)titleForRowInIndexPic:(NSInteger)row;
/** 滚动展示栏的图片数量 */
@property(nonatomic) NSInteger indexPicNumber;


@property (nonatomic, assign)NSInteger page;

@end
