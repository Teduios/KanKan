//
//  NewsViewModel.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsViewModel.h"

@implementation NewsViewModel

- (instancetype)initWithNewsType:(NewsType)type
{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}
//预防性编程，防止没有使用initWithNewsType初始化
- (id)init
{
    if (self = [super init]) {
        NSAssert1(NO, @"%s 必须使用initWithNewsType初始化", __FUNCTION__);
    }
    return self;
}

- (NSInteger)rowNumber
{
    return self.dataArr.count;

}


- (NewsItemModel *)newsItemForArr:(NSArray *)arr row:(NSInteger)row
{
    return arr[row];

}

/** 是否有头部滚动栏 */
- (BOOL)isExistIndexPic
{
    return self.indexPicArr !=nil && self.indexPicArr.count != 0;
}


/** 根据type slide是有多张图 */
- (BOOL)containImages:(NSInteger)row
{
    return [[self newsItemForArr:self.dataArr row:row].type isEqualToString:@"slide"];
}



/** 判断某一行数据是否是专题或web */
- (BOOL)isTopic2:(NSInteger)row
{
    return [[self newsItemForArr:self.dataArr row:row].type isEqualToString:@"topic2"]||[[self newsItemForArr:self.dataArr row:row].type isEqualToString:@"web"];
}
/** 判断某一行数据是否是比赛直播 */
- (BOOL)isSportsLive:(NSInteger)row
{
    return [[self newsItemForArr:self.dataArr row:row].type isEqualToString:@"sports_live"];
}



/** 返回列表中某行数据的图片 */
- (NSURL *)iconURLForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self newsItemForArr:self.dataArr row:row].thumbnail];
}
/** 返回列表中某行数据题目 */
- (NSString *)titleForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].title;
}
/** 返回列表中某行的日期 */
- (NSString *)dateForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].updateTime;
}
/** 返回列表中某行数据评论次数 */
- (NSString *)commentsForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].commentsall;
}

/** 通过行数 返回此行中对应的图片链接数组 */
- (NSArray *)iconURLSForRowInList:(NSInteger)row
{
    NewsItemStyleModel *model = [self newsItemForArr:self.dataArr row:row].style;
    NSArray *images = model.images;
    return images;
}

/** 返回此行中对应的详情页面 */
- (NSString *)detailURLForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].commentsUrl;
}

/** 比赛直播 */
- (NSURL *)leftLogoURLForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self newsItemForArr:self.dataArr row:row].sportsLiveExt.leftLogo];
}
- (NSString *)leftNameForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].sportsLiveExt.leftName;
}
- (NSString *)leftScoreForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].sportsLiveExt.leftScore;
}
- (NSURL *)rightLogoURLForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self newsItemForArr:self.dataArr row:row].sportsLiveExt.rightLogo];
}
- (NSString *)rightNameForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].sportsLiveExt.rightName;
}
- (NSString *)rightScoreForRow:(NSInteger)row
{
    return [self newsItemForArr:self.dataArr row:row].sportsLiveExt.rightScore;
}
- (NSString *)scoreForRow:(NSInteger)row
{
    return [NSString stringWithFormat:@"%@ : %@",[self leftScoreForRow:row],[self rightScoreForRow:row]];
}

/** 判断某一行数据标题是否有图 */
- (BOOL)containIcon:(NSInteger)row
{
    return [[self newsItemForArr:self.dataArr row:row].thumbnail isEqualToString:@""];
}


/** 滚动展示栏的图片 */
- (NSURL *)iconURLForRowInIndexPic:(NSInteger)row
{
    return [NSURL URLWithString:[self newsItemForArr:self.indexPicArr row:row].thumbnail];
}
/** 滚动展示栏的文字 */
- (NSString *)titleForRowInIndexPic:(NSInteger)row
{
    return [self newsItemForArr:self.indexPicArr row:row].title;
}
/** 滚动展示栏的图片数量 */
- (NSInteger)indexPicNumber
{
    return self.indexPicArr.count;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [NewsNetManager getNewsWithType:_type page:_page completionHandle:^(id model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
            self.indexPicArr = nil;
        }
        NSArray *array = model;
        NewsModel *model0 = array[0];
        [self.dataArr addObjectsFromArray:model0.item];
        if (array.count == 2) {
            NewsModel *model1 = array[1];
            self.indexPicArr = model1.item;
        }
        completionHandle(error);
    }];
}
/** 刷新 */
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
/** 加载更多 */
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

@end
