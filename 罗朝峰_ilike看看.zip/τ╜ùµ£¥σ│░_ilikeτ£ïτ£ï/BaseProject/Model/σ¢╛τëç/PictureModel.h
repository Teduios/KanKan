//
//  PictureModel.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class PicMetaModel,Body,PicBodyLinkModel,PicBodyImgModel,PicBodyImgSizeModel;

@interface PictureModel : BaseModel

@property (nonatomic, strong) PicMetaModel *meta;

@property (nonatomic, strong) NSArray<Body *> *body;

@end

@interface PicMetaModel : BaseModel

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, assign) NSInteger expiredTime;

@property (nonatomic, assign) NSInteger pageSize;

@property (nonatomic, copy) NSString *type;

@end

@interface Body : BaseModel

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, assign) NSInteger comments;

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) PicBodyLinkModel *link;

@property (nonatomic, assign) NSInteger likes;

@property (nonatomic, assign) NSInteger cid;

@property (nonatomic, strong) NSArray<PicBodyImgModel *> *img;

@property (nonatomic, assign) NSInteger commentsall;

@property (nonatomic, copy) NSString *shareTitle;

@property (nonatomic, copy) NSString *ctime;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *shareUrl;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *thumbnail;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *staticImg;

@property (nonatomic, copy) NSString *commentsUrl;

@property (nonatomic, copy) NSString *content;

@end

@interface PicBodyLinkModel : BaseModel

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *url;

@end

@interface PicBodyImgModel : BaseModel

@property (nonatomic, copy) NSString *url;

@property (nonatomic, strong) PicBodyImgSizeModel *size;

@end

@interface PicBodyImgSizeModel : BaseModel

@property (nonatomic, copy) NSString *width;

@property (nonatomic, copy) NSString *height;

@end

