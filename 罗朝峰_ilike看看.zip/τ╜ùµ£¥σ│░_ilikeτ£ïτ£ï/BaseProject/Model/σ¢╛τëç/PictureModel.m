//
//  PictureModel.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureModel.h"

@implementation PictureModel


+ (NSDictionary *)objectClassInArray{
    return @{@"body" : [Body class]};
}
@end
@implementation PicMetaModel

@end


@implementation Body

+ (NSDictionary *)objectClassInArray{
    return @{@"img" : [PicBodyImgModel class]};
}

@end


@implementation PicBodyLinkModel

@end


@implementation PicBodyImgModel

@end


@implementation PicBodyImgSizeModel

@end


