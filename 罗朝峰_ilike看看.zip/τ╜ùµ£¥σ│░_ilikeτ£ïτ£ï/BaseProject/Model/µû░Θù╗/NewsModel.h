

//
//  NewsModel.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"



@class NewsItemModel,NewsItemLinkModel,NewsItemStyleModel,NewsItemLiveExtModel,NewsItemSportsLiveExtModel;
@interface NewsModel : BaseModel

@property (nonatomic, strong) NSString *type;

@property (nonatomic, assign) NSInteger expiredTime;

@property (nonatomic, assign) NSInteger currentPage;

@property (nonatomic, strong) NSArray<NewsItemModel *> *item;

@property (nonatomic, strong) NSString *listId;

@property (nonatomic, assign) NSInteger totalPage;

@end

@interface NewsItemModel : BaseModel

@property (nonatomic, strong) NSString *documentId;

@property (nonatomic, strong) NSString *comments;

@property (nonatomic, strong) NSString *ID;

@property (nonatomic, strong) NewsItemLinkModel *link;

@property (nonatomic, strong) NSString *source;

@property (nonatomic, strong) NSString *title;

@property (nonatomic, strong) NSString *commentsall;

@property (nonatomic, strong) NSString *type;

@property (nonatomic, strong) NSString *thumbnail;

@property (nonatomic, strong) NSString *online;

@property (nonatomic, strong) NSString *commentsUrl;

@property (nonatomic, strong) NSString *updateTime;

@property (nonatomic, assign) BOOL hasSlide;

@property (nonatomic, strong) NewsItemStyleModel *style;

@property (nonatomic, strong) NewsItemLiveExtModel *liveExt;

@property (nonatomic, strong) NewsItemSportsLiveExtModel *sportsLiveExt;

@property (nonatomic, strong) NSString *startTimeStr;

@property (nonatomic, strong) NSString *styleType;

@end

@interface NewsItemLinkModel : BaseModel

@property (nonatomic, strong) NSString *type;

@property (nonatomic, strong) NSString *url;

@end

@interface NewsItemStyleModel : BaseModel

@property (nonatomic, strong) NSArray *images;

@property (nonatomic, strong) NSString *type;

@end

@interface NewsItemLiveExtModel : BaseModel

@property (nonatomic, strong) NSString *startTime;

@property (nonatomic, strong) NSString *status;

@end

@interface NewsItemSportsLiveExtModel : BaseModel

@property (nonatomic, strong) NSString *category;
@property (nonatomic, strong) NSString *endTime;
@property (nonatomic, strong) NSString *isOneTitle;
@property (nonatomic, strong) NSString *leftLogo;
@property (nonatomic, strong) NSString *leftName;
@property (nonatomic, strong) NSString *leftScore;
@property (nonatomic, strong) NSString *matchid;
@property (nonatomic, strong) NSString *matchType;
@property (nonatomic, strong) NSString *relateChannel1;
@property (nonatomic, strong) NSString *relateChannel2;
@property (nonatomic, strong) NSString *rightLogo;
@property (nonatomic, strong) NSString *rightName;
@property (nonatomic, strong) NSString *rightScore;
@property (nonatomic, strong) NSString *section;
@property (nonatomic, strong) NSString *sectionstr;
@property (nonatomic, strong) NSString *showScore;
@property (nonatomic, strong) NSString *startTime;
@property (nonatomic, assign) BOOL sync;
@property (nonatomic, strong) NSString *tag;
@property (nonatomic, strong) NSString *time;
@property (nonatomic, strong) NSString *title;

@end
