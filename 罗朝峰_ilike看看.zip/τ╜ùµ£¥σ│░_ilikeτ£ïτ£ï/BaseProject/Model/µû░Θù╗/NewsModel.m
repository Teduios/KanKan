//
//  NewsModel.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsModel.h"


@implementation NewsModel

+ (NSDictionary *)objectClassInArray{
    return @{@"item" : [NewsItemModel class]};
}

@end


@implementation NewsItemModel

@end


@implementation NewsItemLinkModel

@end

@implementation NewsItemStyleModel

@end

@implementation NewsItemLiveExtModel

@end

@implementation NewsItemSportsLiveExtModel

@end


