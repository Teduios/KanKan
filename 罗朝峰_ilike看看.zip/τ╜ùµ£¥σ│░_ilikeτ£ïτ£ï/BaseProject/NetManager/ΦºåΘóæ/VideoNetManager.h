//
//  VideoNetManager.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "VideoModel.h"

@interface VideoNetManager : BaseNetManager

+ (id)getVideoWithIndex:(NSInteger)index kCompletionHandle;

@end
