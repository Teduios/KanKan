//
//  PictureNetManager.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "PictureModel.h"

typedef NS_ENUM(NSUInteger, PictureType) {
    PictureTypeGirl,
    PictureTypePet,
};
@interface PictureNetManager : BaseNetManager

+ (id)getPictureWithType:(PictureType)type page:(NSInteger)page kCompletionHandle;

@end
