//
//  PictureNetManager.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureNetManager.h"

#define kPicturePath    @"http://api.3g.ifeng.com/clientShortNews"

#define kSetType(string,dic)    [dic setObject:string forKey:@"type"];

@implementation PictureNetManager

+ (id)getPictureWithType:(PictureType)type page:(NSInteger)page completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"page":@(page),kGv,kAv,kProid,kOs,kVt,kScreen,kPublishid,kUid}];
    switch (type) {
        case PictureTypeGirl: {
            kSetType(@"beauty", params);
            break;
        }
        case PictureTypePet: {
            kSetType(@"pet", params);
            break;
        }
        default: {
            NSAssert1(NO, @"%s:type类型不正确", __FUNCTION__);
            break;
        }
    }
    
    return [self GET:kPicturePath parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([PictureModel mj_objectWithKeyValues:responseObj],error);
    }];
}

@end
