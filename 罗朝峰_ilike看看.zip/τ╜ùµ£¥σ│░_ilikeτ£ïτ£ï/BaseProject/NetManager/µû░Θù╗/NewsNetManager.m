//
//  NewsNetManager.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsNetManager.h"

#define kNewsPath   @"http://api.iclient.ifeng.com/ClientNews"

#define kSetId(string,dic) [dic setObject:string forKey:@"id"];

@implementation NewsNetManager

+ (id)getNewsWithType:(NewsType)type page:(NSInteger)page kCompletionHandle
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"page":@(page),kGv,kAv,kProid,kOs,kVt,kScreen,kPublishid,kUid}];
    switch (type) {
        case NewsTypeTouTiao: {
            kSetId(@"SYLB10,SYDT10,SYRECOMMEND", params);
            break;
        }
        case NewsTypeYuLe: {
            kSetId(@"YL53,FOCUSYL53", params);
            break;
        }
        case NewsTypeCaiJing: {
            kSetId(@"CJ33,FOCUSCJ33", params);
            break;
        }
        case NewsTypeShiZheng: {
            kSetId(@"SZPD,FOCUSSZPD", params);
            break;
        }
        case NewsTypeJunShi: {
            kSetId(@"JS83,FOCUSJS83", params);
            break;
        }
        case NewsTypeTiYu: {
            kSetId(@"TY43,FOCUSTY43,TYLIVE", params);
            break;
        }
        case NewsTypeLishi: {
            kSetId(@"LS153,FOCUSLS153", params);
            break;
        }
        case NewsTypeKeJi: {
            kSetId(@"KJ123,FOCUSKJ123", params);
            break;
        }
        case NewsTypeQiChe: {
            kSetId(@"QC45,FOCUSQC45", params);
            break;
        }
        case NewsTypeShiShang: {
            kSetId(@"SS78,FOCUSSS78", params);
            break;
        }
        case NewsTypeNuanNews: {
            kSetId(@"NXWPD,FOCUSNXWPD", params);
            break;
        }
        case NewsTypeFunCome: {
            kSetId(@"DZPD,FOCUSDZPD", params);
            break;
        }
        case NewsTypeZhiBo: {
            kSetId(@"ZBPD", params);
            break;
        }
        default: {
            NSAssert1(NO, @"%s:type类型不正确", __FUNCTION__);
            break;
        }
    }
    return [self GET:kNewsPath parameters:params completionHandler:^(id responseObj, NSError *error) {

        completionHandle([NewsModel mj_objectArrayWithKeyValuesArray:responseObj],error);
    }];
    
}





@end
