//
//  NewsNetManager.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "NewsModel.h"

typedef NS_ENUM(NSUInteger, NewsType) {
    NewsTypeTouTiao,    //头条
    NewsTypeYuLe,       //娱乐
    NewsTypeCaiJing,    //财经
    NewsTypeShiZheng,   //时政
    NewsTypeJunShi,     //军事
    NewsTypeTiYu,       //体育
    NewsTypeLishi,      //历史
    NewsTypeKeJi,       //科技
    NewsTypeQiChe,      //汽车
    NewsTypeShiShang,   //时尚
    NewsTypeNuanNews,   //暖新闻
    NewsTypeFunCome,    //FUN来了
    NewsTypeZhiBo,      //直播
};
@interface NewsNetManager : BaseNetManager

+ (id)getNewsWithType:(NewsType)type page:(NSInteger)page kCompletionHandle;


@end
