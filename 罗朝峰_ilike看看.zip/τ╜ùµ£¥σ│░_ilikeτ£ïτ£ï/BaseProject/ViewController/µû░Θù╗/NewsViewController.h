//
//  NewsViewController.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WMPageController.h>

@interface NewsViewController : WMPageController
+ (UINavigationController *)standardNewsNavi;


@end
