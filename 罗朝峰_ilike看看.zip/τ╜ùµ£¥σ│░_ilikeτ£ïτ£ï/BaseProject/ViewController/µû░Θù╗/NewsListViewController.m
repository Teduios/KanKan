//
//  NewsListViewController.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsListViewController.h"
#import "NewsViewModel.h"
#import "NewsViewController.h"
#import "NewsListCell.h"
#import "NewsImageCell.h"
#import "NewsLiveCell.h"
#import "NewsNoIconCell.h"
#import "iCarousel.h"
#import "DetailHtmlViewController.h"

@interface NewsListViewController ()<iCarouselDataSource,iCarouselDelegate>
@property(nonatomic,strong)NewsViewModel *newsVM;
@end

@implementation NewsListViewController
{
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLb;
    NSTimer *_timer;
}
/** 头部滚动视图 */
- (UIView *)headerView
{
    //如果当前没有头部视图，返回nil
    if (!self.newsVM.isExistIndexPic) {
        return nil;
    }
    //创建头部视图
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, kWindowW/320 * 180)];
    
    //添加滚动栏
    _ic = [iCarousel new];
    [headerView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
        //make.left.top.right.mas_equalTo(0);
        //make.bottom.mas_equalTo(bottomView.mas_top).mas_equalTo(0);
    }];
    _ic.delegate = self;
    _ic.dataSource = self;
    _ic.pagingEnabled = YES;
    _ic.scrollSpeed = 1;
    //如果只有一张图，则不可以滚动
    _ic.scrollEnabled = self.newsVM.indexPicNumber != 1;
    
    if (self.newsVM.indexPicNumber > 1) {
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:4 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
    }
    
    //添加底部视图
    UIView *bottomView = [UIView new];
    bottomView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    [headerView addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.mas_equalTo(0);
        make.height.mas_equalTo(35);
    }];
    _titleLb = [UILabel new];
    _titleLb.text = [self.newsVM titleForRowInIndexPic:0];
    _titleLb.textColor = [UIColor whiteColor];
    [bottomView addSubview:_titleLb];
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.centerY.mas_equalTo(0);
    }];
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = self.newsVM.indexPicNumber;
    [bottomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.centerY.mas_equalTo(0);
        make.width.mas_lessThanOrEqualTo(60);
        make.width.mas_greaterThanOrEqualTo(20);
        make.left.mas_equalTo(_titleLb.mas_right).mas_equalTo(-10);
    }];
    _pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    //如果只有一张图，则不显示圆点
    _pageControl.hidesForSinglePage = YES;
    //小圆点不能与用户交互
    _pageControl.userInteractionEnabled = NO;
    return headerView;
}
#pragma mark - iCarousel Delegate
//返回显示界面的个数
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.newsVM.indexPicNumber;
}
//返回每个需要显示的视图
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    if (!view) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/320 *180)];
        UIImageView *imageView = [UIImageView new];
        [view addSubview:imageView];
        imageView.tag = 100;
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        view.clipsToBounds = YES;
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    [imageView setImageWithURL:[self.newsVM iconURLForRowInIndexPic:index]];
    return view;
}
/** 允许循环滚动 */
//此协议方法可以设置每个视图之间的间隙的各种位置属性，还可以通过此协议方法设置是否采用旋转木马效果
- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}

/** 监控当前滚动到第几个 */
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    _titleLb.text = [self.newsVM titleForRowInIndexPic:carousel.currentItemIndex];
    _pageControl.currentPage = carousel.currentItemIndex;
}

- (NewsViewModel *)newsVM
{
    if (!_newsVM) {
        _newsVM = [[NewsViewModel alloc]initWithNewsType:_type.integerValue];
    }
    return _newsVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[NewsListCell class] forCellReuseIdentifier:@"ListCell"];
    [self.tableView registerClass:[NewsImageCell class] forCellReuseIdentifier:@"ImageCell"];
    [self.tableView registerClass:[NewsLiveCell class] forCellReuseIdentifier:@"LiveCell"];
    [self.tableView registerClass:[NewsNoIconCell class] forCellReuseIdentifier:@"NoiconCell"];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.newsVM refreshDataCompletionHandle:^(NSError *error) {
            self.tableView.tableHeaderView = [self headerView];
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.newsVM getMoreDataCompletionHandle:^(NSError *error) {
            self.tableView.tableHeaderView = [self headerView];
            [self.tableView.mj_footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.newsVM.rowNumber;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *title = [self.newsVM titleForRow:indexPath.row];
    NSString *dateInfo = [self.newsVM dateForRow:indexPath.row];
    NSString *dateTail = [dateInfo substringFromIndex:5];
    NSString *date = [dateTail substringToIndex:11];
    NSString *comments = [self.newsVM commentsForRow:indexPath.row];
    
    if ([self.newsVM containImages:indexPath.row]) {
        NewsImageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ImageCell"];
        cell.titleLb.text = title;
        cell.dateLb.text = date;
        if ([comments isEqualToString:@"0"]||comments == nil) {
            cell.commentsLb.hidden = YES;
            cell.commentIV.hidden = YES;
        }else{
            cell.commentsLb.hidden = NO;
            cell.commentIV.hidden = NO;
            cell.commentsLb.text = comments;
        }
        [cell.iconIV1.imageView setImageWithURL:[self.newsVM iconURLSForRowInList:indexPath.row][0]];
        [cell.iconIV2.imageView setImageWithURL:[self.newsVM iconURLSForRowInList:indexPath.row][1]];
        [cell.iconIV3.imageView setImageWithURL:[self.newsVM iconURLSForRowInList:indexPath.row][2]];
        
        return cell;
    }
    if ([self.newsVM isSportsLive:indexPath.row]) {
        NewsLiveCell *cell = [tableView dequeueReusableCellWithIdentifier:@"LiveCell"];
        cell.titleLb.text = title;
        [cell.leftLogo.imageView setImageWithURL:[self.newsVM leftLogoURLForRow:indexPath.row]];
        cell.leftLb.text = [self.newsVM leftNameForRow:indexPath.row];
        cell.score.text = [self.newsVM scoreForRow:indexPath.row];
        [cell.rightLogo.imageView setImageWithURL:[self.newsVM rightLogoURLForRow:indexPath.row]];
        cell.rightLb.text = [self.newsVM rightNameForRow:indexPath.row];
        
        return cell;
    }
    if ([self.newsVM containIcon:indexPath.row]) {
        NewsNoIconCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NoiconCell"];
        cell.titleLb.text = title;
        cell.dateLb.text = date;
        if ([comments isEqualToString:@"0"]||comments == nil) {
            cell.commentsLb.hidden = YES;
            cell.commentIV.hidden = YES;
        }else{
            cell.commentsLb.hidden = NO;
            cell.commentIV.hidden = NO;
            cell.commentsLb.text = comments;
        }
        return cell;
    }
    NewsListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ListCell"];
    [cell.iconIV.imageView setImageWithURL:[self.newsVM iconURLForRow:indexPath.row]];
    cell.titleLb.text = title;
    if ([self.newsVM isTopic2:indexPath.row]) {
        cell.topicLb.hidden = NO;
        cell.dateLb.hidden = YES;
    }else{
        cell.topicLb.hidden = YES;
        cell.dateLb.hidden = NO;
        cell.dateLb.text = date;
    }
    if ([comments isEqualToString:@"0"]||comments == nil) {
        cell.commentsLb.hidden = YES;
        cell.commentIV.hidden = YES;
    }else{
        cell.commentsLb.hidden = NO;
        cell.commentIV.hidden = NO;
        cell.commentsLb.text = comments;
    }

    return cell;
}
/** 去掉分割线左侧缝隙 */
kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DetailHtmlViewController *vc = [[DetailHtmlViewController alloc]initWithURL:[self.newsVM detailURLForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.newsVM containImages:indexPath.row]) {
        return 145;
    }
    if ([self.newsVM isSportsLive:indexPath.row]) {
        return 130;
    }
    return 90;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
