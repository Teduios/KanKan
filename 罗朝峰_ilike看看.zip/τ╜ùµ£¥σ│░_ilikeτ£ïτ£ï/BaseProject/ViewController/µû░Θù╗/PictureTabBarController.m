//
//  PictureTabBarController.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureTabBarController.h"
#import "BeautyViewController.h"
#import "PetViewController.h"

@interface PictureTabBarController ()

@end

@implementation PictureTabBarController
+ (PictureTabBarController *)standardInstance
{
    static PictureTabBarController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [[PictureTabBarController alloc]init];
    });
    return vc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // 取消工具栏的透明状态
    //self.tabBar.translucent = NO;
    //初始化两个子视图，放到tabbar中
    BeautyViewController *beautyVC = [BeautyViewController new];
    PetViewController *petVC = [PetViewController new];
    UINavigationController *beautyNavi = [[UINavigationController alloc]initWithRootViewController:beautyVC];
    UINavigationController *petNavi = [[UINavigationController alloc]initWithRootViewController:petVC];
    self.viewControllers = @[beautyNavi,petNavi];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
