//
//  PetViewController.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PetViewController.h"
#import "PictureViewModel.h"
#import "PictureCell.h"
#import "Factory.h"

@interface PetViewController ()
@property(nonatomic,strong) PictureViewModel *pictureVM;
@end

@implementation PetViewController
- (instancetype)init
{
    if (self = [super init]) {
        self.title = @"萌宠";
        self.tabBarItem.image = [UIImage imageNamed:@"pet"];
    }
    return self;
}

- (PictureViewModel *)pictureVM
{
    if (!_pictureVM) {
        _pictureVM = [[PictureViewModel alloc]initWithPictureType:PictureTypePet];
    }
    return _pictureVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[PictureCell class] forCellReuseIdentifier:@"PetCell"];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.pictureVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.pictureVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
    [Factory addMenuItemToVC:self];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.pictureVM.rowNumber;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PictureCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PetCell"];
    [cell.iconView.imageView setImageWithURL:[self.pictureVM picURLForRow:indexPath.row]];
    cell.likeLb.text = [NSString stringWithFormat:@"%ld",[self.pictureVM likeForRow:indexPath.row]];
    cell.commentsLb.text = [NSString stringWithFormat:@"%ld",[self.pictureVM commentsForRow:indexPath.row]];

    return cell;
}

kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kWindowW +25;
}


@end
