//
//  FooterView.m
//  BaseProject
//
//  Created by apple-jd24 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FooterView.h"

@implementation FooterView
- (NSArray *)items
{
    return @[@"夜间",@"离线",@"反馈",@"设置"];
}
- (NSArray *)icons
{
    return @[@"moon",@"download",@"feedback",@"setting"];
}
- (UILabel *)label
{
    if (!_label) {
        _label = [[UILabel alloc]init];
        _label.font = [UIFont systemFontOfSize:14];
    }
    return _label;
}

- (instancetype)init
{
    if (self = [super init]) {
        CGSize size = CGSizeMake(40, 40);
        UIView *lastView = nil;//指向最新添加的按钮
        for (int i = 0; i < self.icons.count; i++) {
            UIButton *btn = [UIButton buttonWithType:0];
            [btn setImage:[UIImage imageNamed:self.icons[i]] forState:UIControlStateNormal];
            [self addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(size);
                make.top.mas_equalTo(50);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(32);
                }else{
                    make.left.mas_equalTo(32);
                }
            }];
            lastView = btn;
            [self.btns addObject:btn];
            
            UILabel *lastLabel = [[UILabel alloc]init];
            lastLabel.text = self.items[i];
            lastLabel.font = [UIFont systemFontOfSize:14];
            [self addSubview:lastLabel];
            [lastLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerX.mas_equalTo(lastView);
                make.top.mas_equalTo(lastView.mas_bottom).mas_equalTo(7);
            }];
            
            if ([lastLabel.text isEqualToString:@"夜间"]) {
                [btn addTarget:self action:@selector(turnSun:) forControlEvents:UIControlEventTouchUpInside];
                _label = lastLabel;
            }

        }
        
    }
    return self;
}

- (void)turnSun:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn.selected) {
        [btn setImage:[UIImage imageNamed:@"sun"] forState:UIControlStateSelected];
        _label.text = nil;
        _label.text = @"日间";
    }else
    {
        _label.text = nil;
        _label.text = @"夜间";
    }
}

@end
