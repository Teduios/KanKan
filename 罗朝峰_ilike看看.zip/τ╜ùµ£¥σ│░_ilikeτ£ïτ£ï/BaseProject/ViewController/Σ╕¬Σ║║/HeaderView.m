//
//  HeaderView.m
//  BaseProject
//
//  Created by apple-jd24 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HeaderView.h"

@implementation HeaderView

- (instancetype)init
{
    if (self = [super init]) {
        UIButton *btn = [UIButton buttonWithType:0];
        [btn setImage:[UIImage imageNamed:@"login.jpg"] forState:UIControlStateNormal];
        [self addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(30);
            make.size.mas_equalTo(CGSizeMake(45, 45));
        }];
        
        UILabel *label = [[UILabel alloc]init];
        label.text = @"立即登录";
        label.font = [UIFont systemFontOfSize:14];
        [self addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(10);
        }];
    }
    return self;
   
}
@end
