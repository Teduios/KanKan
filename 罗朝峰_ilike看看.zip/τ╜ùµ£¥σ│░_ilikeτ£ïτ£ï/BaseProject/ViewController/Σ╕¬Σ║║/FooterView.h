//
//  FooterView.h
//  BaseProject
//
//  Created by apple-jd24 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FooterView : UIView
@property(nonatomic,strong) NSArray *items;
@property(nonatomic,strong) NSArray *icons;
@property(nonatomic,strong) NSMutableArray *btns;
@property(nonatomic,strong) UILabel *label;
@end
