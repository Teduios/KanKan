//
//  OneselfViewController.m
//  BaseProject
//
//  Created by apple-jd24 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "OneselfViewController.h"
#import "Factory.h"
#import "HeaderView.h"
#import "FooterView.h"
#import "OneselfCell.h"

@interface OneselfViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *items;
@property(nonatomic,strong)NSArray *icons;
@end

@implementation OneselfViewController
+ (UINavigationController *)defaultNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        OneselfViewController *oneVC = [OneselfViewController new];
        navi = [[UINavigationController alloc]initWithRootViewController:oneVC];
    });
    return navi;
}
- (NSArray *)items
{
    return @[@"消息",@"订阅",@"商城",@"评论",@"收藏"];
}
- (NSArray *)icons
{
    return @[@"news",@"book",@"shop",@"comment",@"collect"];
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"cell_bk.jpg"]];
        [_tableView registerClass:[OneselfCell class] forCellReuseIdentifier:@"PersonCell"];
        //头部视图
        HeaderView *header = [[HeaderView alloc]init];
        header.frame = CGRectMake(0, 0, kWindowW, 140);
        _tableView.tableHeaderView = header;
        
        //脚部视图
        FooterView *footer = [[FooterView alloc]init];
        footer.frame = CGRectMake(0, 360, kWindowW, 120);
        _tableView.tableFooterView = footer;
        
        _tableView.scrollEnabled = NO;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OneselfCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PersonCell"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = self.items[indexPath.row];
    cell.imageView.image = [UIImage imageNamed:self.icons[indexPath.row]];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView reloadData];
    
    [Factory addMenuItemToVC:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
