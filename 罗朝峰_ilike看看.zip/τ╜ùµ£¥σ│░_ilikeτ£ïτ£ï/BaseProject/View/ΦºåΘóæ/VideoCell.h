//
//  VideoCell.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
@interface VideoCell : UITableViewCell

@property(nonatomic,strong) UILabel *titleLb;
@property(nonatomic,strong) UILabel *descLb;
@property(nonatomic,strong) UIButton *iconBtn;

@property(nonatomic,strong) NSURL *videoURL;
//+ (AVPlayerViewController *)sharedInstance;
@end
