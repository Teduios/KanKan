//
//  PictureCell.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsImageView.h"
@interface PictureCell : UITableViewCell
@property(nonatomic,strong) NewsImageView *iconView;

@property(nonatomic,strong) UIImageView *likeIV;
@property(nonatomic,strong) UILabel *likeLb;

@property(nonatomic,strong) UIImageView *commentIV;
@property(nonatomic,strong) UILabel *commentsLb;

@end
