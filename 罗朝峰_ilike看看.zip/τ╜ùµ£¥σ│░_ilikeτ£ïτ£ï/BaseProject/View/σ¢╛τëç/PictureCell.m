//
//  PictureCell.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureCell.h"

@implementation PictureCell
- (NewsImageView *)iconView
{
    if (_iconView == nil) {
        _iconView = [[NewsImageView alloc]init];
    }
    return _iconView;
}

- (UIImageView *)likeIV
{
    if (_likeIV == nil) {
        _likeIV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"like"]];
    }
    return _likeIV;
}

- (UILabel *)likeLb
{
    if (_likeLb == nil) {
        _likeLb = [[UILabel alloc]init];
        _likeLb.font = [UIFont systemFontOfSize:14];
    }
    return _likeLb;
}

- (UIImageView *)commentIV
{
    if (_commentIV == nil) {
        _commentIV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pinglun"]];
    }
    return _commentIV;
}

- (UILabel *)commentsLb
{
    if (_commentsLb == nil) {
        _commentsLb = [[UILabel alloc]init];
        _commentsLb.font = [UIFont systemFontOfSize:14];
    }
    return _commentsLb;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconView];
        [self.contentView addSubview:self.likeIV];
        [self.contentView addSubview:self.likeLb];
        [self.contentView addSubview:self.commentIV];
        [self.contentView addSubview:self.commentsLb];
        //图片
        [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(kWindowW-20);
            make.top.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        //赞图片
        [self.likeIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(25);
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_iconView.mas_bottom).mas_equalTo(5);
        }];
        //赞数量标签
        [self.likeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_likeIV);
            make.left.mas_equalTo(_likeIV.mas_right).mas_equalTo(0);
        }];
        //评论数量标签
        [self.commentsLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_likeIV);
            make.right.mas_equalTo(-10);
        }];
        //评论图片
        [self.commentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(20);
            make.centerY.mas_equalTo(_likeIV);
            make.right.mas_equalTo(_commentsLb.mas_left).mas_equalTo(0);
        }];
        
    }
    return self;
}

@end
