//
//  NewsLiveCell.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsImageView.h"
@interface NewsLiveCell : UITableViewCell
/** 头部标签 */
@property(nonatomic,strong)UILabel *headLeft;
@property(nonatomic,strong)UILabel *headRight;
// 题目标签
@property(nonatomic,strong)UILabel *titleLb;
// 左侧logo
@property(nonatomic,strong)NewsImageView *leftLogo;
// 左侧队名
@property(nonatomic,strong)UILabel *leftLb;
// 比分
@property(nonatomic,strong)UILabel *score;
// 右侧logo
@property(nonatomic,strong)NewsImageView *rightLogo;
// 右侧队名
@property(nonatomic,strong)UILabel *rightLb;
@end
