//
//  NewsImageCell.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsImageCell.h"

@implementation NewsImageCell
- (UILabel *)titleLb
{
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:16];
    }
    return _titleLb;
}

- (UILabel *)dateLb
{
    if (_dateLb == nil) {
        _dateLb = [[UILabel alloc]init];
        _dateLb.font = [UIFont systemFontOfSize:14];
        _dateLb.textColor = [UIColor lightGrayColor];
    }
    return _dateLb;
}

- (UILabel *)commentsLb
{
    if (_commentsLb == nil) {
        _commentsLb = [[UILabel alloc]init];
        _commentsLb.font = [UIFont systemFontOfSize:14];
        _commentsLb.textColor = [UIColor lightGrayColor];
    }
    return _commentsLb;
}

- (NewsImageView *)iconIV1
{
    if (_iconIV1 == nil) {
        _iconIV1 = [[NewsImageView alloc]init];
    }
    return _iconIV1;
}

- (NewsImageView *)iconIV2
{
    if (_iconIV2 == nil) {
        _iconIV2 = [[NewsImageView alloc]init];
    }
    return _iconIV2;
}

- (NewsImageView *)iconIV3
{
    if (_iconIV3 == nil) {
        _iconIV3 = [[NewsImageView alloc]init];
    }
    return _iconIV3;
}

- (UIImageView *)commentIV
{
    if (_commentIV == nil) {
        _commentIV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pinglun"]];
    }
    return _commentIV;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.dateLb];
        [self.contentView addSubview:self.iconIV1];
        [self.contentView addSubview:self.iconIV2];
        [self.contentView addSubview:self.iconIV3];
        [self.contentView addSubview:self.commentsLb];
        [self.contentView addSubview:self.commentIV];
        //题目 左上10 右10
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        //图片 宽相等，间距5，边缘10，高度80
        [self.iconIV1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(80);
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_titleLb.mas_bottom).mas_equalTo(5);
        }];
        [self.iconIV2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(_iconIV1);
            make.left.mas_equalTo(_iconIV1.mas_right).mas_equalTo(5);
            make.topMargin.mas_equalTo(_iconIV1);
        }];
        [self.iconIV3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(_iconIV1);
            make.topMargin.mas_equalTo(_iconIV1);
            make.left.mas_equalTo(_iconIV2.mas_right).mas_equalTo(5);
            make.right.mas_equalTo(-10);
        }];
        //日期 左10  上图片5
        [self.dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_iconIV1.mas_bottom).mas_equalTo(5);
        }];
        //评论 上图片5 评论图片0
        [self.commentsLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_iconIV3.mas_bottom).mas_equalTo(5);
            make.right.mas_equalTo(_commentIV.mas_left);
        }];
        //评论图片
        [self.commentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 20));
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(_iconIV3.mas_bottom).mas_equalTo(3);
        }];
    
    }
    return self;
}


@end
