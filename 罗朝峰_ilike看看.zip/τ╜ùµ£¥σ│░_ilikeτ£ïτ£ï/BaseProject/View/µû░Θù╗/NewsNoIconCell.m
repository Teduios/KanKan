//
//  NewsNoIconCell.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsNoIconCell.h"

@implementation NewsNoIconCell
- (UILabel *)titleLb
{
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:16];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}

- (UILabel *)dateLb
{
    if (_dateLb == nil) {
        _dateLb = [[UILabel alloc]init];
        _dateLb.font = [UIFont systemFontOfSize:14];
        _dateLb.textColor = [UIColor lightGrayColor];
    }
    return _dateLb;
}

- (UILabel *)commentsLb
{
    if (_commentsLb == nil) {
        _commentsLb = [[UILabel alloc]init];
        _commentsLb.font = [UIFont systemFontOfSize:14];
        _commentsLb.textColor = [UIColor lightGrayColor];
    }
    return _commentsLb;
}

- (UIImageView *)commentIV
{
    if (_commentIV == nil) {
        _commentIV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pinglun"]];
    }
    return _commentIV;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.dateLb];
        [self.contentView addSubview:self.commentsLb];
        [self.contentView addSubview:self.commentIV];
        //题目 左上10 右10
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        //日期 左10 下10
        [self.dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
        }];
        //评论数 右边缘35，下边缘与左侧图片下边缘对齐
        [self.commentsLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_commentIV.mas_left);
            make.bottomMargin.mas_equalTo(_dateLb.mas_bottomMargin);
        }];
        //评论图片 宽高25，20 距离右边缘10 ，下边缘与左侧图片对齐
        [self.commentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(25);
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(-10);
            make.bottomMargin.mas_equalTo(_dateLb.mas_bottomMargin);
        }];
    }
    return self;
}


@end
