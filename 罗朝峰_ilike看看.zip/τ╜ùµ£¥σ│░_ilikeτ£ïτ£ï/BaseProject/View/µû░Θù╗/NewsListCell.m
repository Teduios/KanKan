//
//  NewsListCell.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsListCell.h"

@implementation NewsListCell
- (NewsImageView *)iconIV
{
    if (_iconIV == nil) {
        _iconIV = [[NewsImageView alloc]init];
    }
    return _iconIV;
}

- (UILabel *)titleLb
{
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:16];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}

- (UILabel *)dateLb
{
    if (_dateLb == nil) {
        _dateLb = [[UILabel alloc]init];
        _dateLb.font = [UIFont systemFontOfSize:14];
        _dateLb.textColor = [UIColor lightGrayColor];
    }
    return _dateLb;
}

- (UILabel *)commentsLb
{
    if (_commentsLb == nil) {
        _commentsLb = [[UILabel alloc]init];
        _commentsLb.font = [UIFont systemFontOfSize:14];
        _commentsLb.textColor = [UIColor lightGrayColor];
    }
    return _commentsLb;
}

- (UIImageView *)commentIV
{
    if (_commentIV == nil) {
        _commentIV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pinglun"]];
    }
    return _commentIV;
}

- (UILabel *)topicLb
{
    if (_topicLb == nil) {
        _topicLb = [[UILabel alloc]init];
        _topicLb.text = @"专题";
        _topicLb.font = [UIFont systemFontOfSize:14];
        _topicLb.textColor = [UIColor whiteColor];
        _topicLb.backgroundColor = [UIColor redColor];
    }
    return _topicLb;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconIV];
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.dateLb];
        [self.contentView addSubview:self.commentsLb];
        [self.contentView addSubview:self.commentIV];
        [self.contentView addSubview:self.topicLb];
        //左侧图片 左10，宽高92，70 竖向居中
        [self.iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(92, 70));
            make.centerY.mas_equalTo(0);
        }];
        //题目 距离图片右边缘8，右边缘10.上边缘低于图片上边缘3
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_iconIV.mas_right).mas_equalTo(8);
            make.right.mas_equalTo(-10);
            make.topMargin.mas_equalTo(_iconIV.mas_topMargin).mas_equalTo(3);
        }];
        //日期 左边缘与题目左边缘对齐，下边缘与图片下边缘对齐
        [self.dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(_titleLb.mas_leftMargin);
            make.bottomMargin.mas_equalTo(_iconIV.mas_bottomMargin);
        }];
        //评论数 右边缘35，下边缘与左侧图片下边缘对齐
        [self.commentsLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_commentIV.mas_left);
            make.bottomMargin.mas_equalTo(_iconIV.mas_bottomMargin);
        }];
        //评论图片 宽高25，20 距离右边缘10 ，下边缘与左侧图片对齐
        [self.commentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(25);
            make.height.mas_equalTo(20);
            make.right.mas_equalTo(-10);
            make.bottomMargin.mas_equalTo(_iconIV.mas_bottomMargin);
        }];
        //专题标签 左边缘与题目左边缘对齐，下边缘与图片下边缘对齐
        [self.topicLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(_titleLb.mas_leftMargin);
            make.bottomMargin.mas_equalTo(_iconIV.mas_bottomMargin);
        }];
    }
    return self;
}


@end
