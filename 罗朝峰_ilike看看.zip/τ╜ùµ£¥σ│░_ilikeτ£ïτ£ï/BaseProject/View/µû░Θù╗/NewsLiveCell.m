//
//  NewsLiveCell.m
//  BaseProject
//
//  Created by apple-jd24 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewsLiveCell.h"

@implementation NewsLiveCell

- (UILabel *)headLeft
{
    if (_headLeft == nil) {
        _headLeft = [[UILabel alloc]init];
        _headLeft.font = [UIFont systemFontOfSize:12];
        _headLeft.text = @"体育直播 | NBA常规赛";
        _headLeft.textColor = [UIColor greenSeaColor];
    }
    return _headLeft;
}

- (UILabel *)headRight
{
    if (_headRight == nil) {
        _headRight = [[UILabel alloc]init];
        _headRight.font = [UIFont systemFontOfSize:12];
        _headRight.text = @"直播中···";
        _headRight.textColor = [UIColor greenSeaColor];
    }
    return _headRight;
}

- (UILabel *)titleLb
{
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:16];
    }
    return _titleLb;
}

- (NewsImageView *)leftLogo
{
    if (_leftLogo == nil) {
        _leftLogo = [[NewsImageView alloc]init];
    }
    return _leftLogo;
}

- (UILabel *)leftLb
{
    if (_leftLb == nil) {
        _leftLb = [[UILabel alloc]init];
        _leftLb.font = [UIFont systemFontOfSize:13];
    }
    return _leftLb;
}

- (UILabel *)score
{
    if (_score == nil) {
        _score = [[UILabel alloc]init];
        _score.font = [UIFont systemFontOfSize:32];
    }
    return _score;
}

- (NewsImageView *)rightLogo
{
    if (_rightLogo == nil) {
        _rightLogo = [[NewsImageView alloc]init];
    }
    return _rightLogo;
}

- (UILabel *)rightLb
{
    if (_rightLb == nil) {
        _rightLb = [[UILabel alloc]init];
        _rightLb.font = [UIFont systemFontOfSize:13];
    }
    return _rightLb;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.headLeft];
        [self.contentView addSubview:self.headRight];
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.leftLogo];
        [self.contentView addSubview:self.leftLb];
        [self.contentView addSubview:self.score];
        [self.contentView addSubview:self.rightLogo];
        [self.contentView addSubview:self.rightLb];
        /** 头部标签 */
        [self.headLeft mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(10);
        }];
        [self.headRight mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_headLeft);
            make.right.mas_equalTo(-10);
        }];
        //题目 左上10 右10
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_headLeft.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        //左侧logo 宽高70 50，左对齐题目，距离题目10，
        [self.leftLogo mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(70);
            make.height.mas_equalTo(50);
            make.leftMargin.mas_equalTo(_titleLb.mas_leftMargin);
            make.top.mas_equalTo(_titleLb.mas_bottom).mas_equalTo(10);
        }];
        //左侧队名 左侧logo正下方2
        [self.leftLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(_leftLogo);
            make.top.mas_equalTo(_leftLogo.mas_bottom).mas_equalTo(2);
        }];
        //比分 屏幕正中
        [self.score mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.centerY.mas_equalTo(_leftLogo);
        }];
        //右侧logo 右10，宽高同左logo
        [self.rightLogo mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.size.centerY.mas_equalTo(_leftLogo);
        }];
        //右侧队名 右侧logo正下方2
        [self.rightLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(_rightLogo);
            make.top.mas_equalTo(_rightLogo.mas_bottom).mas_equalTo(2);
        }];
    }
    return self;
}

@end
