//
//  NewsNoIconCell.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsNoIconCell : UITableViewCell
// 题目标签
@property(nonatomic,strong)UILabel *titleLb;
// 日期标签
@property(nonatomic,strong)UILabel *dateLb;
// 评论标签
@property(nonatomic,strong)UILabel *commentsLb;
// 评论图片
@property(nonatomic,strong)UIImageView *commentIV;

@end
