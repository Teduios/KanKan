//
//  NewsListCell.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsImageView.h"

@interface NewsListCell : UITableViewCell
// 左侧图片
@property(nonatomic,strong)NewsImageView *iconIV;
// 题目标签
@property(nonatomic,strong)UILabel *titleLb;
// 日期标签
@property(nonatomic,strong)UILabel *dateLb;
// 评论标签
@property(nonatomic,strong)UILabel *commentsLb;
// 评论图片
@property(nonatomic,strong)UIImageView *commentIV;
// 专题标签
@property(nonatomic,strong)UILabel *topicLb;
@end
