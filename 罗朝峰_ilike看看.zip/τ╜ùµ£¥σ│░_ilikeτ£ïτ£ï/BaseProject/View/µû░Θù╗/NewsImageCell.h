//
//  NewsImageCell.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsImageView.h"

@interface NewsImageCell : UITableViewCell
// 题目标签
@property(nonatomic,strong)UILabel *titleLb;
// 图片1
@property(nonatomic,strong)NewsImageView *iconIV1;
// 图片2
@property(nonatomic,strong)NewsImageView *iconIV2;
// 图片3
@property(nonatomic,strong)NewsImageView *iconIV3;
// 日期标签
@property(nonatomic,strong)UILabel *dateLb;
// 评论标签
@property(nonatomic,strong)UILabel *commentsLb;
// 评论图片
@property(nonatomic,strong)UIImageView *commentIV;

@end
