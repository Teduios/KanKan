//
//  NewsImageView.h
//  BaseProject
//
//  Created by apple-jd24 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsImageView : UIView
@property(nonatomic,strong)UIImageView *imageView;

@end
