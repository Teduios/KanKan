//
//  OneselfCell.m
//  BaseProject
//
//  Created by apple-jd24 on 15/12/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "OneselfCell.h"

@implementation OneselfCell
- (void)layoutSubviews
{
    [super layoutSubviews];
    self.imageView.frame = CGRectMake(35, 10, 30, 25);
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
